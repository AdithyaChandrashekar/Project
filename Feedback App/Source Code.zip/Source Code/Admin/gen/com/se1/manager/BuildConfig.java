/** Automatically generated file. DO NOT MODIFY */
package com.se1.manager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}