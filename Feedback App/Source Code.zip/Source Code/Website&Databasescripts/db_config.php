<?php
 
/*
 * All database connection variables
 */
 
define('DB_USER', "axm5553"); // db user
define('DB_PASSWORD', "Rb31kU83"); // db password (mention your db password here)
define('DB_DATABASE', "axm5553"); // database name
define('DB_SERVER', "omega.uta.edu"); // db server

/*
define('DB_USER', "root"); // db user
define('DB_PASSWORD', "root"); // db password (mention your db password here)
define('DB_DATABASE', "Feedback"); // database name
define('DB_SERVER', "localhost"); // db server*/
?>